/**
 * @license
 * Copyright (c) 2018 amCharts (Antanas Marcelionis, Martynas Majeris)
 *
 * This sofware is provided under multiple licenses. Please see below for
 * links to appropriate usage.
 *
 * Free amCharts linkware license. Details and conditions:
 * https://github.com/amcharts/amcharts4/blob/master/LICENSE
 *
 * One of the amCharts commercial licenses. Details and pricing:
 * https://www.amcharts.com/online-store/
 * https://www.amcharts.com/online-store/licenses-explained/
 *
 * If in doubt, contact amCharts at contact@amcharts.com
 *
 * PLEASE DO NOT REMOVE THIS COPYRIGHT NOTICE.
 * @hidden
 */
webpackJsonp([150],{1037:function(e,t,o){"use strict";Object.defineProperty(t,"__esModule",{value:!0});var i=o(1038);window.am4geodata_region_usa_dcLow=i.a},1038:function(e,t,o){"use strict";t.a={type:"FeatureCollection",features:[{type:"Feature",geometry:{type:"Polygon",coordinates:[[[-76.932,38.91],[-76.91,38.893],[-76.992,38.829],[-77.02,38.813],[-77.026,38.827],[-77.022,38.871],[-77.057,38.901],[-77.093,38.907],[-77.121,38.934],[-77.041,38.995],[-76.932,38.91]]]},properties:{name:"Washington, District of Columbia",id:"11001",STATE:"DC",TYPE:"Federal District",CNTRY:"USA"},id:"11001"}]}}},[1037]);
//# sourceMappingURL=dcLow.js.map