/**
 * @license
 * Copyright (c) 2018 amCharts (Antanas Marcelionis, Martynas Majeris)
 *
 * This sofware is provided under multiple licenses. Please see below for
 * links to appropriate usage.
 *
 * Free amCharts linkware license. Details and conditions:
 * https://github.com/amcharts/amcharts4/blob/master/LICENSE
 *
 * One of the amCharts commercial licenses. Details and pricing:
 * https://www.amcharts.com/online-store/
 * https://www.amcharts.com/online-store/licenses-explained/
 *
 * If in doubt, contact amCharts at contact@amcharts.com
 *
 * PLEASE DO NOT REMOVE THIS COPYRIGHT NOTICE.
 * @hidden
 */
webpackJsonp([151],{1035:function(e,t,i){"use strict";Object.defineProperty(t,"__esModule",{value:!0});var o=i(1036);window.am4geodata_region_usa_dcHigh=o.a},1036:function(e,t,i){"use strict";t.a={type:"FeatureCollection",features:[{type:"Feature",geometry:{type:"Polygon",coordinates:[[[-76.932,38.91],[-76.91,38.893],[-76.992,38.829],[-77.026,38.801],[-77.026,38.808],[-77.02,38.813],[-77.026,38.827],[-77.022,38.854],[-77.018,38.862],[-77.009,38.868],[-76.994,38.873],[-76.979,38.875],[-76.978,38.882],[-77.006,38.875],[-77.009,38.876],[-77.022,38.871],[-77.026,38.867],[-77.032,38.882],[-77.038,38.888],[-77.057,38.901],[-77.07,38.904],[-77.076,38.901],[-77.093,38.907],[-77.104,38.919],[-77.111,38.922],[-77.121,38.934],[-77.09,38.958],[-77.041,38.995],[-76.932,38.91]]]},properties:{name:"Washington, District of Columbia",id:"11001",STATE:"DC",TYPE:"Federal District",CNTRY:"USA"},id:"11001"}]}}},[1035]);
//# sourceMappingURL=dcHigh.js.map