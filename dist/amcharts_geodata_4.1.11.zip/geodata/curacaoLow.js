/**
 * @license
 * Copyright (c) 2018 amCharts (Antanas Marcelionis, Martynas Majeris)
 *
 * This sofware is provided under multiple licenses. Please see below for
 * links to appropriate usage.
 *
 * Free amCharts linkware license. Details and conditions:
 * https://github.com/amcharts/amcharts4/blob/master/LICENSE
 *
 * One of the amCharts commercial licenses. Details and pricing:
 * https://www.amcharts.com/online-store/
 * https://www.amcharts.com/online-store/licenses-explained/
 *
 * If in doubt, contact amCharts at contact@amcharts.com
 *
 * PLEASE DO NOT REMOVE THIS COPYRIGHT NOTICE.
 * @hidden
 */
am4internal_webpackJsonp(["b014"],{"ozx/":function(e,o,t){"use strict";Object.defineProperty(o,"__esModule",{value:!0});var a={type:"FeatureCollection",features:[{type:"Feature",geometry:{type:"Polygon",coordinates:[[[-68.6421,11.9788],[-68.6435,11.9784],[-68.6435,11.983],[-68.6443,11.9846],[-68.644,11.9854],[-68.6454,11.9879],[-68.6462,11.9887],[-68.647,11.9935],[-68.6474,11.9943],[-68.6474,11.9966],[-68.6485,11.9982],[-68.6482,11.9996],[-68.6448,11.9999],[-68.6418,11.9984],[-68.64,11.9956],[-68.6401,11.9929],[-68.6393,11.9912],[-68.6399,11.9889],[-68.6401,11.9853],[-68.6399,11.9833],[-68.6408,11.9807],[-68.6421,11.9788]]]},properties:{name:"Curaçao",id:"CW",CNTRY:"Curaçao",TYPE:"Constituent"},id:"CW"}]};window.am4geodata_curacaoLow=a}},["ozx/"]);
//# sourceMappingURL=curacaoLow.js.map