/**
 * @license
 * Copyright (c) 2018 amCharts (Antanas Marcelionis, Martynas Majeris)
 *
 * This sofware is provided under multiple licenses. Please see below for
 * links to appropriate usage.
 *
 * Free amCharts linkware license. Details and conditions:
 * https://github.com/amcharts/amcharts4/blob/master/LICENSE
 *
 * One of the amCharts commercial licenses. Details and pricing:
 * https://www.amcharts.com/online-store/
 * https://www.amcharts.com/online-store/licenses-explained/
 *
 * If in doubt, contact amCharts at contact@amcharts.com
 *
 * PLEASE DO NOT REMOVE THIS COPYRIGHT NOTICE.
 * @hidden
 */!function(e){var t={};function r(o){if(t[o])return t[o].exports;var n=t[o]={i:o,l:!1,exports:{}};return e[o].call(n.exports,n,n.exports,r),n.l=!0,n.exports}r.m=e,r.c=t,r.d=function(e,t,o){r.o(e,t)||Object.defineProperty(e,t,{configurable:!1,enumerable:!0,get:o})},r.n=function(e){var t=e&&e.__esModule?function(){return e.default}:function(){return e};return r.d(t,"a",t),t},r.o=function(e,t){return Object.prototype.hasOwnProperty.call(e,t)},r.p="",r(r.s=1128)}({1128:function(e,t,r){e.exports=r(1129)},1129:function(e,t,r){"use strict";Object.defineProperty(t,"__esModule",{value:!0});var o=r(1130);window.am4geodata_region_usa_dcHigh=o.a},1130:function(e,t,r){"use strict";t.a={type:"FeatureCollection",features:[{type:"Feature",geometry:{type:"Polygon",coordinates:[[[-76.932,38.91],[-76.91,38.893],[-76.992,38.829],[-77.026,38.801],[-77.026,38.808],[-77.02,38.813],[-77.026,38.827],[-77.022,38.854],[-77.018,38.862],[-77.009,38.868],[-76.994,38.873],[-76.979,38.875],[-76.978,38.882],[-77.006,38.875],[-77.009,38.876],[-77.022,38.871],[-77.026,38.867],[-77.032,38.882],[-77.038,38.888],[-77.057,38.901],[-77.07,38.904],[-77.076,38.901],[-77.093,38.907],[-77.104,38.919],[-77.111,38.922],[-77.121,38.934],[-77.09,38.958],[-77.041,38.995],[-76.932,38.91]]]},properties:{name:"District of Columbia",id:"C11001",STATE:"DC",FIPS:"11001",TYPE:"Federal District",CNTRY:"USA"},id:"C11001"}]}}});
//# sourceMappingURL=dcHigh.js.map